package com.rohan.csds233.assignment1;

import java.util.*;

public class CourseList {
	private Course[] listOfCourses = new Course[10];
	
	public int size() {                                       //👍
		int size = 0;
		Object x = null;
		for(int i = 0; i < listOfCourses.length; i++) {
			if(listOfCourses[i] != null) {
				size++;
			}
		}
		return size;
	}
	
	public void addCourse(int i, Course course) {             //👍
		if(i < listOfCourses.length) {
			listOfCourses[i] = course;
		} else {
			listOfCourses[listOfCourses.length - 1] = course;
		}
	}
	
	public boolean removeCourse(int i) {                    //👍
		/*boolean removed = false;
		try {
			listOfCourses[i] = null;
			removed = true;
		} catch(Exception ex) {
			removed = false;
		}
		return removed;*/
		for(int j = i; j < size(); j++) {
			listOfCourses[j] = listOfCourses[j+1];
		}
		return true;
	}
	
	public boolean changeCapacity(String courseID, int capacity) {             //👍
		for(int i = 0; i < listOfCourses.length; i++) {
			if(listOfCourses[i].getCourseID().equals(courseID)) {
				listOfCourses[i].setCapacity(capacity);
				return true;
			}
		}
		return false;
	}
	
	public Course getCourseWithIndex(int i) {                                 //👍
		if(i < listOfCourses.length) {
			return listOfCourses[i];
		}
		return null;
	}
	
	public int searchCourseId(String courseID) {
		for(int i = 0; i < listOfCourses.length; i++) {
			if(listOfCourses[i] != null) {
				if(listOfCourses[i].getCourseID().equals(courseID)) {
					return i;
				}
			}
		}
		return -1;
	}
	
	public int searchCourseName(String courseName) {
		for(int i = 0; i < listOfCourses.length; i++) {
			if(listOfCourses[i].getCourseName().equals(courseName)) {
				return i;
			}
		}
		return -1;
	}
	
	
}





