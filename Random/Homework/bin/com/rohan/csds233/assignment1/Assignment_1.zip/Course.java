package com.rohan.csds233.assignment1;

public class Course {
	private String courseId;
	private String courseName;
	private int capacity;
	
	public void setCourseID(String courseId) {
		this.courseId = courseId;
	}
	
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public String getCourseID() {
		return courseId;
	}
	
	public String getCourseName() {
		return courseName;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	
}
